let score = 0;

let b1 = document.getElementById("b1");

let scoreText = document.getElementById("score");

b1.onclick = () => {

  score++;

  scoreText.textContent = score;

  b1.style.transform = "scale(0.95)";

  setTimeout(() => {

    b1.style.transform = "scale(1)";

  }, 100);

};

let plus = document.getElementById("plus");

b1.onclick = () => {

  score++;

  scoreText.textContent = score;

  plus.style.opacity = 1;

  setTimeout(() => {

    plus.style.opacity = 0;

  }, 300);

};

if (score == 10) {

  info.textContent = "Ого, уже 10 котов!";

};

let selectedItem = null;

let selectedCount = 1;

const items = [

  {

    id: "click",

    name: "➕ Клик",

    desc: "+1 к силе клика",

    cost: 10,

    multi: true,

    buy: (count)=> clickPower += count

  },

  {

    id: "auto",

    name: "🤖 Авто",

    desc: "+1 авто в секунду",

    cost: 50,

    multi: true,

    buy: (count)=> autoClickers += count

  },

  {

    id: "mega",

    name: "🔥 Мега",

    desc: "x2 ко всем кликам",

    cost: 4000,

    multi: false,

    bought: false,

    buy: ()=> clickPower *= 2

  }

];

function renderShop(){

  const box = $("shopItems");

  box.innerHTML = "";

  items.forEach(it=>{

    const div = document.createElement("div");

    div.className = "shop-item";

    div.innerHTML = `<b>${it.name}</b><br>${it.desc}`;

    div.onclick = ()=> openItemModal(it);

    box.appendChild(div);

  });

};

function openItemModal(item){

  selectedItem = item;

  selectedCount = 1;

  $("itemTitle").textContent = item.name;

  $("itemDesc").textContent = item.desc;

  $("itemPrice").textContent = item.cost;

  if(item.multi){

    $("itemCountBox").style.display = "flex";

  } else {

    $("itemCountBox").style.display = "none";

  }

  $("itemCount").textContent = selectedCount;

  $("itemModal").classList.add("show");

}

$("plusBtn").onclick = ()=>{

  selectedCount++;

  $("itemCount").textContent = selectedCount;

};

$("minusBtn").onclick = ()=>{

  if(selectedCount > 1){

    selectedCount--;

    $("itemCount").textContent = selectedCount;

  }

};

$("buyItemBtn").onclick = ()=>{

  let price = selectedItem.cost * selectedCount;

  if(score < price){

    alert("Не хватает рыб!");

    return;

  }

  if(selectedItem.multi){

    selectedItem.buy(selectedCount);

  } else {

    if(selectedItem.bought){

      alert("Уже куплено!");

      return;

    }

    selectedItem.bought = true;

    selectedItem.buy();

  }

  score -= price;

  save();

  update();

  $("itemModal").classList.remove("show");

};

$("closeItemModal").onclick = ()=>{

  $("itemModal").classList.remove("show");

};